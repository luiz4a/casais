import React from 'react';

function Perfil() {
  return (
    <div className="main">
      <h1>Perfil do Casal</h1>
      <p>Veja informações do casal e lugares favoritos!</p>
      <div style={{background:'#fff0f6', borderRadius:'12px', padding:'2rem', color:'#ff4b6e', margin:'2rem auto', maxWidth:'400px'}}>
        <p style={{color:'#c2185b'}}><b>Nome do casal:</b> </p>
        <p style={{color:'#c2185b'}}><b>Lugares favoritos:</b> </p>
        <p style={{color:'#c2185b'}}><i>Em breve: edição de perfil!</i></p>
      </div>
    </div>
  );
}

export default Perfil;
