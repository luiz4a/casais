//C:\Users\aluno.den\Downloads\atividadeEm_dupla\restaurante_rev\src\pages\BemVindo\index.js

import React, { useState } from "react";
import { useNavigate } from 'react-router-dom'; // Importa o hook
import './style.css';
import logo from '../../assets/images/rev21.png'; // Ajuste o caminho conforme necessário


function BemVindo() {
    const navigate = useNavigate(); 
    const [menuOpen, setMenuOpen] = useState(false);

    // Fecha o menu ao navegar
    const handleNavigate = (path) => {
      setMenuOpen(false);
      navigate(path);
    };

  return (
    <div className="background">
      <div className="overlay">
        <header className="header">
          <img src={logo} alt="Logo Casal" className="logo" />
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Abrir menu">
            &#9776;
          </button>
          <nav>
            <ul className={`nav${menuOpen ? ' open' : ''}`}>
              <li onClick={() => handleNavigate('/chat')}>Chat</li>
              <li onClick={() => handleNavigate('/localizacao')}>Localização</li>
              <li onClick={() => handleNavigate('/datas')}>Datas Especiais</li>
              <li onClick={() => handleNavigate('/perfil')}>Perfil</li>
            </ul>
          </nav>
        </header>

        <main className="main">
          <h1>Bem-vindos, Casal!</h1>
          <p>Este é o espaço de vocês para conversar, compartilhar momentos, marcar datas especiais e se encontrar!</p>
          <button onClick={() => navigate('/chat')} className="button-cadastro">
            Começar a Conversar
          </button>
        </main>
      </div>
    </div>
  );
}

export default BemVindo;