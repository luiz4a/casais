import React from 'react';

function Datas() {
  return (
    <div className="main">
      <h1>Datas Especiais</h1>
      <p>Registre e lembre datas importantes do casal!</p>
      <ul style={{background:'#fff0f6', borderRadius:'12px', padding:'2rem', color:'#ff4b6e', margin:'2rem auto', maxWidth:'400px'}}>
        <li style={{color:'#c2185b'}}>Dia do namoro</li>
        <li style={{color:'#c2185b'}}>Aniversário de casamento</li>
        <li style={{color:'#c2185b'}}>Primeiro beijo</li>
        <li style={{color:'#c2185b'}}>Outras datas marcantes...</li>
      </ul>
    </div>
  );
}

export default Datas;
