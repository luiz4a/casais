import React from 'react';

function Chat() {
  return (
    <div className="main">
      <h1>Chat do Casal</h1>
      <p>Converse com seu par em tempo real!</p>
      <div style={{background:'#fff0f6', borderRadius:'12px', padding:'2rem', color:'#ff4b6e', margin:'2rem auto', maxWidth:'400px'}}>
        <p style={{color:'#c2185b'}}><i>Em breve: chat romântico aqui!</i></p>
      </div>
    </div>
  );
}

export default Chat;
