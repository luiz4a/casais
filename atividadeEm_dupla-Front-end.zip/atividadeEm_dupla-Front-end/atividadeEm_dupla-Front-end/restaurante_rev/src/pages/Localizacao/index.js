import React from 'react';

function Localizacao() {
  return (
    <div className="main">
      <h1>Localização do Casal</h1>
      <p>Veja onde está seu par!</p>
      <div style={{background:'#fff0f6', borderRadius:'12px', padding:'2rem', color:'#ff4b6e', margin:'2rem auto', maxWidth:'400px'}}>
        <p style={{color:'#c2185b'}}><i>Em breve: mapa e localização aqui!</i></p>
      </div>
    </div>
  );
}

export default Localizacao;
