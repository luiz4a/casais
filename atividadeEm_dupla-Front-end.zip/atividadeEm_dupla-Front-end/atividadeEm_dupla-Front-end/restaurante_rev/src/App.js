import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import PaginaBemVindo from './pages/BemVindo';
// Novas páginas para o app de casais
import PaginaChat from './pages/Chat';
import PaginaLocalizacao from './pages/Localizacao';
import PaginaDatas from './pages/Datas';
import PaginaPerfil from './pages/Perfil';
import './App.css';

function App() {
  return (
      <Routes>
        <Route path="/" element={<PaginaBemVindo />} />  
        <Route path="/chat" element={<PaginaChat />} />
        <Route path="/localizacao" element={<PaginaLocalizacao />} />
        <Route path="/datas" element={<PaginaDatas />} />
        <Route path="/perfil" element={<PaginaPerfil />} />
      </Routes>
  );
}

export default App;